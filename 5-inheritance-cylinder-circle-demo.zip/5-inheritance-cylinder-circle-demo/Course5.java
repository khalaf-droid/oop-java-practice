
package com.mycompany.course5;
import java.util.Scanner;
public class Course5 {

    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
      cylinder c1=new cylinder(4,10);
        System.out.println(c1.area());
        System.out.println(c1.volum());
        System.out.println(c1.toString());
    }
}
