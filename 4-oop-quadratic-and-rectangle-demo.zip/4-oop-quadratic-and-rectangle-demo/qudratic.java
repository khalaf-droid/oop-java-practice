package com.mycompany.course4;

public class qudratic {
    private double a,b,c;
    public qudratic(){
    a=1; b=2; c=3;
    }
    public qudratic(double x,double y,double z){
    a=x; b=y;c=z;
    }
    public void output(){
    double z=(b*b)-(4*a*c);
    if(z>0){
    double root1=(-b-Math.sqrt(z))/(2*a);
    double root2=(-b+Math.sqrt(z))/(2*a);
        System.out.println("the root is "+root1+" "+root2);
    }
    else 
            System.out.println("no root");
    }
}