package com.mycompany.course6;
public class Course6 {

    public static void main(String[] args) {
        rectangle r1=new rectangle(12.8,2.88);
          System.out.println(r1.getarea());
          r1.getpremater();
    }
}
