package com.mycompany.course9;

public class Course9 {
    public static double getAverage(int x,int y,int z)throws ArithmeticException,Exception{
    if (x<0||y<0||z<0)
        throw new ArithmeticException("negative number");
    else if(x==0||y==0||z==0)
         throw new Exception("zero number");
    else
        return(x+y+z)/3.0;
    }

    public static void main(String[] args)throws ArithmeticException,Exception {
     /* try {
        int[]arr=new int [-8];
        String s1="13.55";
        int x=Integer.parseInt(s1);
        String s2="hello";
        System.out.println(s2.charAt(5)); 
        int[]arr1={3,6,9};
        for(int i=0;i<=arr.length;i++)
                 System.out.println(arr[i]); 
        }
         catch(NumberFormatException e){
            System.out.println("error enformat of number");
        }
        catch(NegativeArraySizeException e){
            System.out.println("size of array can not be negative");
        }
        catch(Exception e){
            System.out.println("error");
        }
        finally{
            System.out.println("goodbye");
        }*/
        System.out.println(getAverage(13,5,8));
         System.out.println(getAverage(0,5,8));
    } 
}