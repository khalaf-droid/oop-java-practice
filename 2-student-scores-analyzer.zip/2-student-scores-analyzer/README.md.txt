# Student Scores Analyzer

This Java console application allows the user to input the scores of 10 students, then calculates:

- The maximum score
- The minimum score (and the student number who got it)
- The average score

## 🔹 Concepts Used:
- Arrays
- Loops (for)
- Conditional logic
- Basic statistics (max, min, average)
- User input using Scanner

## 🛠️ Language:
- Java
