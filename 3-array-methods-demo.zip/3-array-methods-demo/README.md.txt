# Array Methods Demo in Java

This Java application demonstrates basic usage of arrays with methods:

- Returning arrays from methods
- Passing arrays as method parameters
- Printing array contents

## 🔹 Concepts Used:
- Arrays
- Methods with return types
- Method parameters
- Static methods
- Data types: int[] and double[]

## 🛠️ Language:
- Java
