package com.mycompany.course6;
public class square extends rectangle {

    public square() {
    }

    public square(double side) {
        super(side,side);
    }

    public square(double side, String color, boolean filled) {
        super(side,side, color, filled);
    }
    public double getside(){
    return super.getwidth();
    }
     public void setside(double side){
       super.setlength(side);
       super.setwidth(side);
    }
     public void setlength(double side){
       super.setlength(side);
    }
     public void setwidth(double side){
       super.setwidth(side);
     }
    public String toString() {
       return "A square with side = "+super.getwidth()+" which is a subclass of"+super.toString();
    }
}
