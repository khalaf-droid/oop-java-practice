package com.mycompany.course4;
import java.util.Scanner;
public class Course4 {
    public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
        System.out.println("enter 3 coofient");
        double a=scan.nextDouble();
        double b=scan.nextDouble();
        double c=scan.nextDouble();
       qudratic q1=new qudratic(a,b,c); 
       q1.output();
    }
}
