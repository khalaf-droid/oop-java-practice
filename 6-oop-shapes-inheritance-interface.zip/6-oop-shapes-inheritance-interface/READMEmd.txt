# OOP: Shapes – Inheritance and Interfaces Demo

This Java project showcases a comprehensive implementation of Object-Oriented Programming using geometric shapes.

## 🧠 OOP Concepts Demonstrated:
- Inheritance (Circle, Rectangle, Square inherit from Shape)
- Interfaces (`shape2` implemented by `rectangle2` and `square2`)
- Encapsulation (private fields + getters/setters)
- Method Overriding (`toString`, `getarea`, `getpremater`)
- Constructor Overloading
- Polymorphism through interfaces

## 🏗️ Class Structure:

### Abstract Layer:
- `shape`: Base class with color and fill status
- `shape2`: Interface with area, perimeter, and print methods

### Concrete Shapes:
- `rectangle`, `circle`, `square`: Extend `shape`
- `rectangle2`, `square2`: Implement `shape2`

### Main Test Class:
- `Course6`: Demonstrates instantiating and interacting with `rectangle`

## 🚀 Output Sample:
- Prints area and perimeter of a rectangle object
- Can be extended to test other shapes

## 🛠️ Language:
- Java
