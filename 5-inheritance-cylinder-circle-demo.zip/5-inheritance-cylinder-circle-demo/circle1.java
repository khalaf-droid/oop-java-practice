package com.mycompany.course5;
public class circle1 {
   public final double pi=3.14;
   private int radius;

    public circle1() {
        radius=3;
    }
    public circle1(int radius) {
        this.radius = radius;
    }
    public int getRadius() {
        return radius;
    }
    public void setRadius(int radius) {
        this.radius = radius;
    }
    public String toString() {
        return "this is super class" ;
    }
    public double area(){
        return pi*radius*radius;
}
   
   
}
