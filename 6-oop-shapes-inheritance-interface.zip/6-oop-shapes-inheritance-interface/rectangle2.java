package com.mycompany.course6;
public class rectangle2 implements shape2  {
    private double length,width;
    
    public rectangle2(double length, double width) {
        this.length = length;
        this.width = width;
    }
    public double getLength() {
        return length;
    }
    public void setLength(double length) {
        this.length = length;
    }
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        this.width = width;
    }
    public double getarea() {
        return length*width;
    }
    public double getpremater() {        
        return 2*(length+width);        
    }
    public void print() {   
        System.out.println("this is rectangle class");
    }
    
}
