package com.mycompany.course6;
public class square2 implements shape2  {
    private double side;

    public square2(double side) {
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }
    
    public double getarea() {
         
        return side*side;
         
    }
    public double getpremater() {
         
        return 4*side;
         
    }
    public void print() {
         System.out.println("this is square class");
    }
    
}
