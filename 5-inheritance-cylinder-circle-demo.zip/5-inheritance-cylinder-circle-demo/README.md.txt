# OOP Inheritance: Cylinder and Circle Demo

This Java project demonstrates the concept of inheritance and method overriding in Object-Oriented Programming.

## 🔹 Classes Overview:

### `circle1`
- Represents a basic circle
- Contains radius, area calculation, and a `toString()` method

### `cylinder`
- Inherits from `circle1`
- Adds height and volume calculation
- Overrides `toString()` to show subclass message

### `circle`
- Separate class to explore constructor overloading and circle properties

### `Course5`
- Main class to test `cylinder` creation and its functionalities

## 🧠 OOP Concepts Used:
- Inheritance
- Method overriding
- Constructor overloading
- Encapsulation
- Object creation and interaction

## 🛠️ Language:
- Java
