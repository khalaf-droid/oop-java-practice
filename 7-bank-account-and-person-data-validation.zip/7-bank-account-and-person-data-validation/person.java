package com.mycompany.course7;
public class person {
    private String name;
    private int age;
    private String phone,Email,bdate;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if(age>=20&&age<=40)
        this.age = age;
        else
            System.out.println("error in range");
    }
    private void ensurename(){
    boolean s1=false,s2=false,s3=false;
    if(name.length()>0)
        s1=true;
    if(name.length()<=20)
        s3=true;
    int i=0;
     while(i<name.length()){
      char ch=name.charAt(i);
      if(Character.isAlphabetic(ch))
           s2=true;
      else{s2=false;break;}
      if(s1&&s2&&s3)
        System.out.println("valid name");
      else
          System.out.println("invlid name");
       }
    } 
    public void get(){
         System.out.println(name+" "+age);   
    }
    public void set(String newName,int newAge){
        name=newName;
        age=newAge;
    }
    public void validPhone(){
     if(phone.length()==11&&(phone.startsWith("010")||phone.startsWith("012")||phone.startsWith("015")))
       System.out.println("Valid phone number");
     else
       System.out.println("Invalid phone number");
    }
    public void validEmail(){
       int x1=Email.indexOf("@");
       int x2=Email.indexOf(".");
       if(Email.contains("@.")&&x1<x2)
       System.out.println("valid Email");
    else
       System.out.println("Invalid Email");
    }
}

