package com.mycompany.course6;
public interface shape2 {
    public double getarea();
    public double getpremater();
    public void print();
}
