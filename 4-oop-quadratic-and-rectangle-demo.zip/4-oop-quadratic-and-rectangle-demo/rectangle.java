package com.mycompany.course4;
public class rectangle {
    private int length,width;
    public rectangle(){
    length=3;
    width=5;
    }

public rectangle(int length,int width){
this.length=length;
this.width= width;
}
public int getlength(){
return length;
}
public int getwidth(){
return width;
}
public void setlength(int length){
this.length=length;
}
public void setwidth(int width){
this.width=width;
}
public int area(){
return length*width;
}
public void premater(){
    int x = 2*(length+width);
    System.out.println(x);
}
}