# Java Exception Handling Demo

This project demonstrates how to handle exceptions in Java using both built-in and custom exceptions.

## 🧠 Features:
- `getAverage()` method throws:
  - `ArithmeticException` for negative values
  - `Exception` for zero values

- Example code includes:
  - Negative array size
  - Number format conversion errors
  - String indexing errors
  - Array index out of bounds

- Demonstrates the use of:
  - `try`, `catch`, `finally`
  - Custom exception messages
  - Multiple catch blocks

## 🚀 Sample Output:
```java
System.out.println(getAverage(13,5,8)); // 8.67
System.out.println(getAverage(0,5,8));  // Throws: Exception("zero number")
