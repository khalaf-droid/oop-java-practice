package com.mycompany.course5;
public class cylinder extends circle1 {
     private int hight; 

    public cylinder() {
        super();
        hight=5;
    }
    public cylinder(int hight, int radius) {
        super(radius);
        this.hight = hight;
    }

    public int getHight() {
        return hight;
    }

    public void setHight(int hight) {
        this.hight = hight;
    }

    
    public String toString() {
        return "this is sub class";
    }
     public double volum(){
     return super.area()*hight;
     }
    
     
}
