package com.mycompany.course7;
import java.util.Scanner;
public class Course7 {

    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("inter account information ");
        String name=scan.next();
        String number=scan.next();
        double balance=scan.nextDouble();
        bankacount acount=new bankacount(number,name,balance);
        System.out.println("enter amount to deposite");
        double x=scan.nextDouble();
        acount.deposit(x);
        System.out.println("Enter amount to withdraw");
        double y=scan.nextDouble();
        acount.withdrow(y);
        acount.displayaccountinfo();
    }
}
