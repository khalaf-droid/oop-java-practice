package com.mycompany.course6;
public class rectangle extends shape {
private double width;
private double length;
    public rectangle() {
        width=1.0;
        length=1.0;
    }
    public rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }
    public rectangle(double width, double length, String color, boolean filled) {
        super(color, filled);
        this.width = width;
        this.length = length;
    }
    public double getwidth() {
        return width;
    }
    public void setwidth(double width) {
        this.width = width;
    }
    public double getLength() {
        return length;
    }
    public void setlength(double length) {
        this.length = length;
    }
    public double getarea(){
    return length*width;
    }
    public double getpremater(){
    return 2*(length+width);
    }
    public String toString() {
        return "the width is "+width+"length "+length +", which is asubclass of "+super.toString();
    }
    
}
