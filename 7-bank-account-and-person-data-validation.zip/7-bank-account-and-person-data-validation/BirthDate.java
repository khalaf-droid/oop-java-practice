package com.mycompany.course7;
  public class BirthDate {
    private int Day,month,year;
    public BirthDate(int Day, int month, int year) {
        this.Day = Day;
        this.month = month;
        this.year = year;
    }
    public int getDay() {
    return Day;
    }
    public void setDay(int Day) {
    this.Day = Day; 
    }
    public int getMonth() {
    return month;
    }
    public void setMonth(int month) {
    this.month = month;
    }
    public int getYear() {
    return year;
    }
    public void setYear(int year) {
    this.year = year;
    }
    public void validBirthDate(){
      if((Day>=1&&Day<=31)&&(month>=1&&month<=12)&&(year<=2023))
          System.out.println("valid Birthdate");
      else
          System.out.println("Invalid Birthdate");
    }
}

