# Bank Account and Person Data Validation System

This Java project simulates a mini system for managing bank accounts and validating personal data.

## 📦 Modules Included:

### `bankacount`
- Manages a user's bank account information
- Allows deposit, withdrawal, and account info display

### `person`
- Stores personal data (name, age, phone, email, birthdate)
- Validates input values for correctness

### `BirthDate`
- A helper class to validate the format of a date of birth

### `Course7`
- The main class to interact with the user and demonstrate functionality

## 🧠 Key Concepts:
- Class & object design
- Encapsulation
- Input validation
- Console input using `Scanner`
- Data modeling and integrity checks

## 🛠️ Language:
- Java
