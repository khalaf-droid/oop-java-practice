# Even or Odd Checker in Java

This is a simple Java console program that takes an integer input from the user and determines whether it is even or odd.

### 🔹 Concepts Used:
- Conditional statements (if-else)
- Method extraction (basic encapsulation)
- User input using Scanner
