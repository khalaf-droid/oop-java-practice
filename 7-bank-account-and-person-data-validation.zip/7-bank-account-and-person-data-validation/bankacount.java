package com.mycompany.course7;
public class bankacount {
    private String number,holder_name;
    private double balance;

    public bankacount(String number, String holder_name, double balance) {
        this.number = number;
        this.holder_name = holder_name;
        this.balance = balance;
    }
    public String getNumber() {
        return number;
    }
    public void setNumber(String number) {
        this.number = number;
    }
    public String getHolder_name() {
        return holder_name;
    }
    public void setHolder_name(String holder_name) {
        this.holder_name = holder_name;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void deposit(double amount){
       balance+=amount;
        System.out.println("amount added succesfully");
    }
    public void withdrow(double amount){
    if(amount<=balance)
        balance-=amount;
    else
            System.out.println("can't withdrow this amount");
    }
    public void displayaccountinfo(){
        System.out.println("the data are "+number+" "+holder_name+" "+balance);
    }

}
