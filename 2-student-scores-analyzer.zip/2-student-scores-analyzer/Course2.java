package com.mycompany.course2;

import java.util.Scanner;

public class Course2 {
   

    public static void main(String[] args) {
Scanner scan=new Scanner(System.in);
int[] arr=new int[10];
System.out.println("enter degree of 10 student ");//عملنا جملة الطباعة برا عشان متتكررش معانا
for(int i=0;i<arr.length;i++){//  طب لو عملناهيديك اكسبشن  <=length هو غدد الخانات
     arr[i]=scan.nextInt();
}
int max=arr[0];
for(int i=0;i<arr.length;i++){
if(arr[i]>max)
    max=arr[i];
}
        System.out.println("max num is "+max);
        int min=arr[0] , index=0;
for(int i=0;i<arr.length;i++){
if(arr[i]<min)
    min=arr[i];
index=i;
}
        System.out.println("stud with min score "+(index+1));
        int total=0;
        
for(int i=0;i<arr.length;i++){
total+=arr[i];
}
        System.out.println("average of score "+(total/arr.length));
    }

}
