package com.mycompany.course3;

import java.util.Scanner;

public class Course3 {
    public static void printArray(int[]arr){
    for(int i=0;i<arr.length;i++)
        System.out.println(arr[i]);
    }
    public static double[] getArray(){
    double[] y={2.6,1.3,3.9};
    return y;
    }       
    public static void main(String[] args) {
        double[]arr2=getArray();
        
        
        Scanner scan = new Scanner(System.in);
        
    }
}

