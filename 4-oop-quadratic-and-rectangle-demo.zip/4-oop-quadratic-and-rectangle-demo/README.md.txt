# OOP: Quadratic Equation Solver & Rectangle Class Demo

This Java application demonstrates Object-Oriented Programming concepts by implementing:

- A quadratic equation solver (`qudratic.java`)
- A rectangle class with area and perimeter calculations (`rectangle.java`)

## 🧠 OOP Concepts Used:
- Class & Object creation
- Encapsulation (private fields, getters/setters)
- Constructors (default and parameterized)
- Method creation and usage
- Conditional logic & math operations

## 🚀 How It Works:
- The program asks the user to input 3 coefficients (a, b, c) of a quadratic equation.
- It calculates the roots using the formula and prints the result.
- A separate class `rectangle` demonstrates how to use constructors and methods for geometric shapes.

## 🛠️ Language:
- Java
